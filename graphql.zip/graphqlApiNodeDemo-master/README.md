# Setup a GraphQL API with Apollo 2.0 Sequelize and Express.js

## Instructions
Please do follow the instructions in the article published on [medium](https://medium.com/infocentric/setup-a-graphql-api-with-apollo-2-0-sequelize-and-express-js-608d1365d776).
